//
//  GameViewController.swift
//  FruitFrenzy
//
//  Created by Danis Harmandic on 3. 4. 2023..
//

import SwiftUI
import ARKit
import SceneKit
import AVFoundation
import SpriteKit

struct GameViewControllerRepresentable: UIViewControllerRepresentable {
    @ObservedObject var gameData: GameData
    
    class Coordinator: GameViewControllerDelegate {
        var gameData: GameData
        
        init(gameData: GameData) {
            self.gameData = gameData
        }
        
        var gameBegan = false {
            didSet {
                gameData.gameBegan = gameBegan
            }
        }
        
        var gameOver = false {
            didSet {
                gameData.gameOver = gameOver
            }
        }
        
        var score = 0 {
            didSet {
                gameData.score = score
            }
        }
    }
    
    func makeUIViewController(context: Context) -> GameViewController {
        let gameViewController = GameViewController()
        gameViewController.delegate = context.coordinator
        return gameViewController
    }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(gameData: gameData)
    }
    
    func updateUIViewController(_ uiViewController: GameViewController, context: Context) {
        
    }
}

protocol GameViewControllerDelegate {
    var gameBegan: Bool { get set }
    var gameOver: Bool { get set }
    var score: Int { get set }
}

class GameViewController: UIViewController {
    var delegate: GameViewControllerDelegate!
    
    var arView: ARSCNView!
    var skView: SKView!
    var coachingView: ARCoachingOverlayView!
    
    var anchorNode: SCNNode?
    var lastTouchedBody: SCNNode?
    
    var sliceSFX: AVAudioPlayer!
    var swipeParticle = SKEmitterNode(fileNamed: "swipe")!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let sliceSFXPath = Bundle.main.path(forResource: "slash", ofType: "mp3")!
        sliceSFX = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sliceSFXPath))
        sliceSFX.prepareToPlay()
        
        arView = ARSCNView(frame: view.frame)
        arView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        arView.delegate = self
        
        skView = SKView(frame: view.frame)
        skView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        skView.allowsTransparency = true
        skView.backgroundColor = .clear
        
        view.addSubview(skView)
        view.addSubview(arView)
        
        let scene = SKScene(size: view.frame.size)
        scene.backgroundColor = .clear
        swipeParticle.targetNode = scene
        
        scene.addChild(swipeParticle)
        skView.presentScene(scene)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = .horizontal
        
        arView.session.run(config)
        arView.session.delegate = self
        
        coachingView = ARCoachingOverlayView(frame: view.frame)
        coachingView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        coachingView.goal = .horizontalPlane
        coachingView.session = arView.session
        
        view.addSubview(coachingView)
        
        let ambientLight = SCNLight()
        ambientLight.type = .ambient
        ambientLight.intensity = 200
        let ambientLightNode = SCNNode()
        ambientLightNode.light = ambientLight
        arView.scene.rootNode.addChildNode(ambientLightNode)
        
        let directionalLight = SCNLight()
        directionalLight.type = .directional
        directionalLight.intensity = 500
        let directionalLightNode = SCNNode ()
        directionalLightNode.light = directionalLight
        directionalLightNode.eulerAngles = SCNVector3(Float.pi/4,
                                                      Float.pi/4, 0)
        arView.scene.rootNode.addChildNode(directionalLightNode)
        
        arView.scene.physicsWorld.gravity.y = -1
        arView.scene.physicsWorld.contactDelegate = self
    }
    
    func startGame() {
        let groundPlane = SCNPlane(width: 10, height: 10)
        let groundNode = SCNNode(geometry: groundPlane)
        groundNode.eulerAngles.x = -.pi/2
        groundNode.opacity = 0
        
        groundNode.physicsBody = SCNPhysicsBody(type: .kinematic, shape: nil)
        groundNode.physicsBody?.categoryBitMask = BitMask.ground
        groundNode.physicsBody?.contactTestBitMask = BitMask.healthyFood | BitMask.unhealthyFood | BitMask.slicedFood
        
        anchorNode?.addChildNode(groundNode)
        
        DispatchQueue.main.asyncAfter (deadline: .now() + 3) {
            self.throwObject()
        }
    }
    
    @objc func throwObject() {
        guard !delegate.gameOver else { return }
        let isHelathy = Int.random(in: 1...10) > 3
        let objectToThrow = isHelathy ? healthyObjects : unhealthyObjects
        guard let object = objectToThrow.randomElement()??.rootNode.clone() else { return }
        
        object.physicsBody = SCNPhysicsBody(type: .dynamic, shape: nil)
        object.physicsBody?.categoryBitMask = isHelathy ? BitMask.healthyFood : BitMask.unhealthyFood
        object.physicsBody?.contactTestBitMask = BitMask.ground
        
        object.physicsBody?.applyForce(SCNVector3(
            .random(in: -0.3...0.3),
            1.5,
            .random(in: -0.3...0.3)
        ), asImpulse: true)
        
        object.physicsBody?.applyTorque(SCNVector4(
            .random(in: -1...1),
            .random(in: -1...1),
            .random(in: -1...1),
            0.01
        ), asImpulse: true)
        
        anchorNode?.addChildNode(object)
        
        object.position = SCNVector3(
            .random(in: -0.1...0.1),
            0.2,
            .random(in: -0.1...0.1)
        )
        
        Timer.scheduledTimer(timeInterval: .random(in: 1...3), target: self, selector: #selector(throwObject), userInfo: nil, repeats: false)
    }
}
