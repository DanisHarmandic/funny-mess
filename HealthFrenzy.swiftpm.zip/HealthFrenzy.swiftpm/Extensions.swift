//
//  Extensions.swift
//  HealthFrenzy
//
//  Created by Danis Harmandic on 10. 4. 2023..
//

import SwiftUI

extension View {
    func navigationStack() -> some View {
        self
            .background(Color.black)
            .edgesIgnoringSafeArea(.all)
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
    }
}
    
public extension View {
    func basicEaseIn(using animation: Animation = Animation.easeIn(duration: 1), delayCount: Double, _ action: @escaping () -> Void) -> some View {
        let delay = animation.delay(delayCount)
        
        return onAppear {
            withAnimation(delay) {
                action()
            }
        }
    }
}

struct NavigationButtonStyle: ButtonStyle {
    var color: Color
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(width: 200, height: 60, alignment: .center)
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                .fill(color)
                .frame(width: 150, height: 50)
                .clipped(), alignment: .center)
            .font(.system(size: 17, weight: .bold, design: .default))
            .foregroundColor(.white)
    }
}
