//
//  WelcomeTextView.swift
//  HealthFrenzy
//
//  Created by Danis Harmandic on 10. 4. 2023..
//

import SwiftUI

struct WelcomeTextView: View {
    
    var subtitle: String
    var subtitleColor: Color
    
    var title: String
    var titleSize: CGFloat
    var title2: String
    
    var bodyIsOn: Bool
    var bodyText: String
    var bodyText2: String
    var bodyTextColor: Color
    var bodyTextSize: CGFloat
    var bodyPaddingTop: CGFloat
    var bodyWidth: CGFloat
    
    @State var subtitleOpacity = 0.0
    @State var titleOpacity = 0.0
    @State var bodyTextOpacity = 0.0
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Subtitle
            Text(subtitle)
                .font(.system(size: 14, weight: .semibold, design: .default))
                .foregroundColor(subtitleColor)
                .opacity(subtitleOpacity)
                .basicEaseIn(delayCount: 0) {
                    subtitleOpacity = 1.0
                }
            
            // Title
            Text(title)
                .font(.system(size: titleSize, weight: .bold, design: .default))
                .foregroundColor(Color.primary)
                .padding(.top, 5)
                .opacity(titleOpacity)
                .basicEaseIn(delayCount: 0.2) {
                    titleOpacity = 1.0
                }
            
            if bodyIsOn {
                Text(bodyText)
                    .foregroundColor(bodyTextColor)
                    .frame(width: bodyWidth, alignment: .leading)
                    .clipped()
                    .font(.system(size: bodyTextSize, weight: .medium, design: .default))
                    .padding(.top, bodyPaddingTop)
                    .opacity(bodyTextOpacity)
                    .basicEaseIn(delayCount: 0.4) {
                        bodyTextOpacity = 1.0
                    }
            }
            
            Text(title2)
                .font(.system(size: titleSize, weight: .bold, design: .default))
                .foregroundColor(Color.primary)
                .padding(.top, 5)
                .opacity(titleOpacity)
                .basicEaseIn(delayCount: 0.6) {
                    titleOpacity = 1.0
                }
            
            Text(bodyText2)
                .foregroundColor(bodyTextColor)
                .frame(width: bodyWidth, alignment: .leading)
                .clipped()
                .font(.system(size: bodyTextSize, weight: .medium, design: .default))
                .padding(.top, bodyPaddingTop)
                .opacity(bodyTextOpacity)
                .basicEaseIn(delayCount: 0.8) {
                    bodyTextOpacity = 1.0
                }
        }
    }
    
}
