import SwiftUI

@main
struct MyApp: App {
    @State private var showingAlert = true
    
    var body: some Scene {
        WindowGroup {
                WelcomeScreen()
            }
        }
    }
