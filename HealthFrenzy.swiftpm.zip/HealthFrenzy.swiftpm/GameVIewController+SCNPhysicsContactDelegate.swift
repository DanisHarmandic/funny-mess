//
//  GameVIewController+SCNPhysicsContactDelegate.swift
//  FruitFrenzy
//
//  Created by Danis Harmandic on 3. 4. 2023..
//

import SwiftUI
import SceneKit

extension GameViewController: SCNPhysicsContactDelegate {
    func physicsWorld(_ world: SCNPhysicsWorld, didEnd contact: SCNPhysicsContact) {
        var objectNode: SCNNode
        
        if contact.nodeA.physicsBody?.categoryBitMask == BitMask.ground {
            objectNode = contact.nodeB
        } else if contact.nodeA.physicsBody?.categoryBitMask == BitMask.ground{
            objectNode = contact.nodeA
        } else {
            return
        }
        
        if objectNode.physicsBody?.categoryBitMask == BitMask.healthyFood {
            delegate.gameOver = true
        }
        
        objectNode.runAction(SCNAction.sequence([
            SCNAction.fadeOut(duration: 1),
            SCNAction.removeFromParentNode()
        ]))
    }
}
