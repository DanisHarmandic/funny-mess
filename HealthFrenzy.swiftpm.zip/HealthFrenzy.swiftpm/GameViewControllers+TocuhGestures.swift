//
//  GameViewControllers+TocuhGestures.swift
//  FruitFrenzy
//
//  Created by Danis Harmandic on 3. 4. 2023..
//

import SwiftUI
import ARKit

extension GameViewController: ARSessionDelegate {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: skView.scene!)
        swipeParticle.position = location
        swipeParticle.particleBirthRate = 300
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        swipeParticle.particleBirthRate = 0
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let locationSKView = touch.location(in: skView.scene!)
        swipeParticle.position = locationSKView
        
        let location = touch.location(in: view)
        guard let hitObject = arView.hitTest(location).first?.node.parent, hitObject != lastTouchedBody, !delegate.gameOver else { return }
        
        if hitObject.physicsBody?.categoryBitMask == BitMask.healthyFood {
            delegate.score += 1
        } else if hitObject.physicsBody?.categoryBitMask == BitMask.unhealthyFood {
            delegate.gameOver = true
        } else {
            return
        }
        
        let sliceParticle = SCNParticleSystem(named: "slice.scnp", inDirectory: nil)!
        let sliceNode = SCNNode()
        sliceNode.position = hitObject.presentation.position
        
        anchorNode?.addChildNode(sliceNode)
        sliceNode.addParticleSystem(sliceParticle)
        
        lastTouchedBody = hitObject
        sliceSFX.play()
    }
    
    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        guard let hitObject = lastTouchedBody else { return }
        
        for child in hitObject.childNodes {
            let childTransform = hitObject.convertTransform(child.transform, to: anchorNode)
            child.removeFromParentNode()
            child.transform = childTransform
            
            child.physicsBody = SCNPhysicsBody(type: .dynamic, shape: nil)
            child.physicsBody?.categoryBitMask = BitMask.slicedFood
            child.physicsBody?.contactTestBitMask = BitMask.ground | BitMask.slicedFood
            child.physicsBody?.velocity = hitObject.physicsBody?.velocity ?? SCNVector3Zero
            child.physicsBody?.angularVelocity = hitObject.physicsBody?.angularVelocity ?? SCNVector4Zero
            
            child.physicsBody?.applyTorque(SCNVector4(
                .random(in: -1...1),
                .random(in: -1...1),
                .random(in: -1...1),
                0.005
            ), asImpulse: true)
            
            anchorNode?.addChildNode(child)
        }
        
        hitObject.removeFromParentNode()
        lastTouchedBody = nil
    }
}
