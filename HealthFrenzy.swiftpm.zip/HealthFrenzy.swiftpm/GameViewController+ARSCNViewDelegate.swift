//
//  GameViewController+ARSCNViewDelegate.swift
//  FruitFrenzy
//
//  Created by Danis Harmandic on 3. 4. 2023..
//

import SwiftUI
import ARKit
import SceneKit

extension GameViewController: ARSCNViewDelegate {
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        guard !delegate.gameBegan && anchor is ARPlaneAnchor else { return nil }
        delegate.gameBegan = true
        
        coachingView.setActive(false, animated: true)
        coachingView.activatesAutomatically = false
        
        anchorNode = SCNNode()
        startGame()
        
        return anchorNode
    }
}
