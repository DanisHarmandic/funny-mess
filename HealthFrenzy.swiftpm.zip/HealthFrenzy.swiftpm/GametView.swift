import SwiftUI

class GameData: ObservableObject {
    @Published var gameBegan = false
    @Published var gameOver = false
    @Published var score = 0
}

struct GameView: View {
    @ObservedObject var gameData = GameData()
    
    var body: some View {
        if gameData.gameBegan {
            ZStack {
                GameViewControllerRepresentable(gameData: gameData)
                    .ignoresSafeArea()
                
                VStack {
                    Text("Score: \(gameData.score)")
                        .font(.title)
                    
                    Spacer()
                    
                    if gameData.gameOver {
                        Text("GAME OVER!")
                            .font(.system(size: 60))
                            .bold()
                            .foregroundColor(.red)
                    }
                    
                    Spacer()
                }
                .padding()
            }
        }
    }
}
