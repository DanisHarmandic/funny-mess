//
//  Misc.swift
//  FruitFrenzy
//
//  Created by Danis Harmandic on 6. 4. 2023..
//

import SceneKit

let healthyObjects = [
    SCNScene(named: "apple.scn"),
    SCNScene(named: "banana.scn"),
    SCNScene(named: "watermelon.scn")
]

let unhealthyObjects = [
    SCNScene(named: "icecream.scn"),
    SCNScene(named: "cupcake.scn"),
    SCNScene(named: "donut.scn")
]

struct BitMask {
    static var ground = 1 << 0
    static var healthyFood = 1 << 1
    static var unhealthyFood = 1 << 2
    static var slicedFood = 1 << 3
}
