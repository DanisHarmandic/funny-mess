//
//  WelcomeScreen.swift
//  HealthFrenzy
//
//  Created by Danis Harmandic on 13. 4. 2023..
//
import SwiftUI

struct WelcomeScreen: View {
    @State var nextPage: Bool = false
    @State var navigationButtonOpacity = 0.0
    @State var showGameView = false
    
    var body: some View {
        if showGameView {
            GameView()
        } else {
            VStack {
                VStack(alignment: .leading, spacing: 0) {
                    WelcomeTextView(subtitle: "HealthFrenzy", subtitleColor: Color.green, title: "Welcome", titleSize: 28, title2: "How To Play", bodyIsOn: true, bodyText: "HealthFrenzy is an AR game for iOS designed to promote healthy eating habits and raise awareness about nutrition, combining interactive gameplay for a fun and engaging experience.", bodyText2: "Using your device's camera and augmented reality technology, you can play this game anywhere you want. As you play, you'll see a variety of fruits and sweets popping up on your screen, and your task is to slice as many fruits as you can while avoiding the sweets. The app tracks your score, so challenge yourself to beat it with each new game. Have fun!", bodyTextColor: Color.secondary, bodyTextSize: 14, bodyPaddingTop: 20, bodyWidth: 700)
                }
                
                HStack(alignment: .bottom, spacing: 0) {
                    Button {
                        showGameView = true
                    } label: {
                        Text("New Button")
                    }
                    .foregroundColor(.blue)
                    .padding(.leading, 20)
                    .padding(.bottom, 40)
                    
                    Spacer()
                    
                    Button {
                        showGameView = true
                    } label: {
                        Text("Play")
                    }
                    .buttonStyle(NavigationButtonStyle(color: .blue))
                    .padding(.leading, 20)
                    .padding(.bottom, 20)
                    .opacity(navigationButtonOpacity)
                    .basicEaseIn(delayCount: 1, {
                        navigationButtonOpacity = 1.0
                    })
                }
            }
        }
    }
}
